@extends('errors::layout')

@section('title', 'Error')

@section('message', 'Whoops, looks like something went wrong.')

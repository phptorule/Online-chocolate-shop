<?php
use PHPUnit\Framework\TestCase;

class Issue1570Test extends TestCase
{
    public function testOne()
    {
        print '*';
    }
}

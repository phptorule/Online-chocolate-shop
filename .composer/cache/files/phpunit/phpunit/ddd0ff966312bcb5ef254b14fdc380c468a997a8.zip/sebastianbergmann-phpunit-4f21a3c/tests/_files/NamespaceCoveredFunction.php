<?php
namespace foo;

function func()
{
    return true;
}

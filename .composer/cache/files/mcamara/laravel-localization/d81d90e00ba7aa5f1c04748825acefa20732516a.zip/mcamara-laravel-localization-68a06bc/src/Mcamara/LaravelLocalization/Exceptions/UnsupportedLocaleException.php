<?php

namespace Mcamara\LaravelLocalization\Exceptions;

use Exception;

class UnsupportedLocaleException extends Exception
{
}

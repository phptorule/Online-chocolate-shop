<?php declare(strict_types=1);

namespace PhpParser\Lexer;

class Emulative extends \PhpParser\Lexer
{
    /* No features requiring emulation have been added in PHP > 7.0 */
}

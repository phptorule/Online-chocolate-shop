<?php

namespace Faker\Provider\it_CH;

class Text extends \Faker\Provider\it_IT\Text
{

}

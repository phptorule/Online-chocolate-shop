<?php

namespace Defuse\Crypto\Exception;

class BadFormatException extends \Defuse\Crypto\Exception\CryptoException
{
}

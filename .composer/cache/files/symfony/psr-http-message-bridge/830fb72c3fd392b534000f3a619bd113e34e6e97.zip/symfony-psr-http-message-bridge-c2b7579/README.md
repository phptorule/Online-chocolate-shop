PSR-7 Bridge
============

Provides integration for PSR7.

Resources
---------

If you want to run the unit tests, install dev dependencies before
running PHPUnit:

    $ cd path/to/Symfony/Bridge/PsrHttpMessage/
    $ composer.phar install
    $ phpunit

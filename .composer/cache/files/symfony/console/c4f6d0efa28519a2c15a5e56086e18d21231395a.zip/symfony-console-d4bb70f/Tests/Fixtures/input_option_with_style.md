#### `--option_name|-o`

option description

* Accept value: yes
* Is value required: yes
* Is multiple: no
* Default: `'style'`

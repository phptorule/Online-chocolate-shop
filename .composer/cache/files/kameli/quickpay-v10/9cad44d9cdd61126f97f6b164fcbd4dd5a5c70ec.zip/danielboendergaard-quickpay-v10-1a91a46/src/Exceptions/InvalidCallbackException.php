<?php

namespace Kameli\Quickpay\Exceptions;

use Exception;

class InvalidCallbackException extends Exception
{

}

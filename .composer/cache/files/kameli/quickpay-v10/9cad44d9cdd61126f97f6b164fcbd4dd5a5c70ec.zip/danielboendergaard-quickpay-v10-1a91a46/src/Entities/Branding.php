<?php

namespace Kameli\Quickpay\Entities;

class Branding extends Entity
{

}
